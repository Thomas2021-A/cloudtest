/**
 * Issue Model Class
 * Represents an issue / task entity in the Issue Tracking System
 */
class Issue {
    constructor(
        id = null,
        summary = '',
        description = '',
        project = null,
        assignee = null,
        createdBy = null,
        createdOn = '',
        lastUpdated = '',
        sprint = '1',
        storyPoint = 2,
        tags = '',
        priority = 'MEDIUM',
        status = 'TO_DO',
        type = 'TASK'
    ) {
        this.id = id;
        this.summary = summary;
        this.description = description;
        this.project = project;
        this.assignee = assignee;
        this.createdBy = createdBy;
        this.createdOn = createdOn;
        this.lastUpdated = lastUpdated;
        this.sprint = sprint;
        this.storyPoint = storyPoint;
        this.tags = tags;
        this.priority = priority;
        this.status = status;
        this.type = type;
    }
}

export default Issue;
