import axios from "axios";

export const ISSUE_API_URL = '/api/issues';

/**
 * Fetch all issues
 * Calls GET /api/issues
 */
export const getAllIssues = async () => {
    try {
        const response = await axios.get(ISSUE_API_URL);
        return response.data;
    } catch (error) {
        console.error('Error fetching all issues - ', error);
        if (error.response?.data?.errorMessage?.includes('No issues') || error.response?.status === 404) {
            return [];
        }
        throw error;
    }
};

/**
 * Fetch a single issue by its ID
 * Calls GET /api/issues/{id}
 */
export const getIssueById = async (id) => {
    try {
        const response = await axios.get(`${ISSUE_API_URL}/${id}`);
        return response.data;
    } catch (error) {
        console.error('Error fetching issue by ID - ', error);
        const serverMsg = error.response?.data?.errorMessage || error.response?.data?.message || 'Issue not found.';
        throw new Error(serverMsg);
    }
};

/**
 * Fetch issues by Project ID
 * Calls GET /api/issues/project/{projectId}
 */
export const getIssuesByProjectId = async (projectId) => {
    try {
        const response = await axios.get(`${ISSUE_API_URL}/project/${projectId}`);
        return response.data;
    } catch (error) {
        console.error('Error fetching issues by project ID - ', error);
        if (error.response?.data?.errorMessage?.includes('No issues discovered') || error.response?.status === 404) {
            return [];
        }
        return [];
    }
};

/**
 * Fetch issues by Project Owner (creator) ID
 * Calls GET /api/issues/owner/{ownerId}
 */
export const getIssuesByOwnerId = async (ownerId) => {
    try {
        const response = await axios.get(`${ISSUE_API_URL}/owner/${ownerId}`);
        return response.data;
    } catch (error) {
        console.error('Error fetching issues by owner ID - ', error);
        if (error.response?.data?.errorMessage?.includes('No issues discovered') || error.response?.status === 404) {
            return [];
        }
        return [];
    }
};

/**
 * Fetch issues assigned to an Assignee
 * Calls GET /api/issues/assignee/{assigneeId}
 */
export const getIssuesByAssigneeId = async (assigneeId) => {
    try {
        const response = await axios.get(`${ISSUE_API_URL}/assignee/${assigneeId}`);
        return response.data;
    } catch (error) {
        console.error('Error fetching issues by assignee ID - ', error);
        if (error.response?.data?.errorMessage?.includes('No issues discovered') || error.response?.status === 404) {
            return [];
        }
        return [];
    }
};

/**
 * Create a new issue
 * Calls POST /api/issues
 */
export const createIssue = async (issue) => {
    try {
        const response = await axios.post(ISSUE_API_URL, issue);
        return response.data;
    } catch (error) {
        console.error('Error creating issue - ', error);
        const serverMsg = error.response?.data?.errorMessage || error.response?.data?.message || (typeof error.response?.data === 'string' ? error.response.data : error.message);
        throw new Error(serverMsg || 'Failed to create issue.');
    }
};

/**
 * Update an existing issue
 * Calls PUT /api/issues/{id}
 */
export const updateIssue = async (id, issue) => {
    try {
        const response = await axios.put(`${ISSUE_API_URL}/${id}`, issue);
        return response.data;
    } catch (error) {
        console.error('Error updating issue - ', error);
        const serverMsg = error.response?.data?.errorMessage || error.response?.data?.message || 'Failed to update issue.';
        throw new Error(serverMsg);
    }
};