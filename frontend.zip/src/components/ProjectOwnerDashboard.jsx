import { useContext, useEffect, useState, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import Sidebar from "./Sidebar";
import TopBar from "./TopBar";
import IssueCard from "./IssueCard";
import { getProjectsByOwner } from "../services/projectService";
import { getIssuesByProjectId } from "../services/issueService";
import { getAllUsers } from "../services/userService";

/**
 * ProjectOwnerDashboard Component
 * - Header with Project Title on right and Search bar on left
 * - Search bar filters issues using RegEx matching on summary & description
 * - If 0 projects: displays "No Projects Available !" and link to "Create Project"
 * - Project Names dropdown: first project chosen by default
 * - Project Owner name displayed as a label
 * - Start & End date displayed in (dd-mm-yyyy)
 * - Front-end filters by Assignee and Priority
 * - 4 Kanban columns: TO-DO, Development, Testing, Completed with counts
 * - Card clicks open Issue Detail Screen
 */
function ProjectOwnerDashboard() {
    const { user } = useContext(AuthContext);
    const navigate = useNavigate();

    // Data states
    const [projects, setProjects] = useState([]);
    const [selectedProjectId, setSelectedProjectId] = useState(null);
    const [issues, setIssues] = useState([]);
    const [usersMap, setUsersMap] = useState({});

    // Filter states
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedAssignee, setSelectedAssignee] = useState('ALL');
    const [selectedPriority, setSelectedPriority] = useState('ALL');
    const [loading, setLoading] = useState(true);

    // Format date string to dd-mm-yyyy
    const formatDate = (dateStr) => {
        if (!dateStr) return '';
        if (/^\d{2}-\d{2}-\d{4}/.test(dateStr)) return dateStr;
        const parts = dateStr.split('-');
        if (parts.length === 3) {
            return `${parts[2]}-${parts[1]}-${parts[0]}`;
        }
        return dateStr;
    };

    // Load users map for avatar & name lookups
    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const allUsers = await getAllUsers();
                const map = {};
                if (Array.isArray(allUsers)) {
                    allUsers.forEach(u => {
                        map[u.userId] = u;
                    });
                }
                setUsersMap(map);
            } catch (err) {
                console.warn('Error loading users:', err);
            }
        };
        fetchUsers();
    }, []);

    // Load projects owned by current user
    useEffect(() => {
        const fetchProjects = async () => {
            if (!user?.userId) return;
            setLoading(true);
            try {
                const ownerProjects = await getProjectsByOwner(user.userId);
                const safeProjects = Array.isArray(ownerProjects) ? ownerProjects : [];
                setProjects(safeProjects);

                // PDF Requirement: The first project from the API Response should be chosen by default
                if (safeProjects.length > 0) {
                    setSelectedProjectId(safeProjects[0].id);
                } else {
                    setSelectedProjectId(null);
                }
            } catch (err) {
                console.error('Error fetching owner projects:', err);
            } finally {
                setLoading(false);
            }
        };

        fetchProjects();
    }, [user]);

    // Fetch issues whenever selected project changes
    useEffect(() => {
        const fetchIssues = async () => {
            if (!selectedProjectId) {
                setIssues([]);
                return;
            }
            try {
                const projectIssues = await getIssuesByProjectId(selectedProjectId);
                setIssues(Array.isArray(projectIssues) ? projectIssues : []);
            } catch (err) {
                console.error('Error loading project issues:', err);
                setIssues([]);
            }
        };

        fetchIssues();
    }, [selectedProjectId]);

    // Current selected project object
    const currentProject = useMemo(() => {
        return projects.find(p => Number(p.id) === Number(selectedProjectId)) || null;
    }, [projects, selectedProjectId]);

    // Distinct list of team members/assignees for the filter
    const projectAssignees = useMemo(() => {
        const ids = [...new Set(issues.map(i => i.assignee).filter(Boolean))];
        return ids.map(id => usersMap[id] || { userId: id, name: `User #${id}` });
    }, [issues, usersMap]);

    // Filter issues on the frontend based on:
    // 1. RegEx search on summary and description
    // 2. Assignee filter
    // 3. Priority filter
    const filteredIssues = useMemo(() => {
        return issues.filter(issue => {
            // RegEx search filter
            if (searchQuery.trim() !== '') {
                try {
                    const regex = new RegExp(searchQuery.trim(), 'i');
                    const matchSummary = regex.test(issue.summary || '');
                    const matchDesc = regex.test(issue.description || '');
                    if (!matchSummary && !matchDesc) return false;
                } catch {
                    // Fallback to substring match if user typed invalid regex characters
                    const q = searchQuery.toLowerCase();
                    const matchSummary = (issue.summary || '').toLowerCase().includes(q);
                    const matchDesc = (issue.description || '').toLowerCase().includes(q);
                    if (!matchSummary && !matchDesc) return false;
                }
            }

            // Assignee filter
            if (selectedAssignee !== 'ALL') {
                if (String(issue.assignee) !== String(selectedAssignee)) {
                    return false;
                }
            }

            // Priority filter
            if (selectedPriority !== 'ALL') {
                if ((issue.priority || '').toUpperCase() !== selectedPriority) {
                    return false;
                }
            }

            return true;
        });
    }, [issues, searchQuery, selectedAssignee, selectedPriority]);

    // Group issues by category column (TO_DO, DEVELOPMENT, TESTING, COMPLETED/DONE)
    const todoIssues = useMemo(() => {
        return filteredIssues.filter(i => {
            const s = (i.status || '').toUpperCase();
            return s === 'TO_DO' || s === 'TO-DO' || s === '1';
        });
    }, [filteredIssues]);

    const devIssues = useMemo(() => {
        return filteredIssues.filter(i => {
            const s = (i.status || '').toUpperCase();
            return s === 'DEVELOPMENT' || s === 'IN_PROGRESS' || s === '2';
        });
    }, [filteredIssues]);

    const testIssues = useMemo(() => {
        return filteredIssues.filter(i => {
            const s = (i.status || '').toUpperCase();
            return s === 'TESTING' || s === '3';
        });
    }, [filteredIssues]);

    const doneIssues = useMemo(() => {
        return filteredIssues.filter(i => {
            const s = (i.status || '').toUpperCase();
            return s === 'DONE' || s === 'COMPLETED' || s === '4';
        });
    }, [filteredIssues]);

    const handleCardClick = (issue) => {
        navigate(`/issue-details/${issue.id}`);
    };

    return (
        <div className="dashboard-layout">
            {/* Sidebar */}
            <Sidebar />

            {/* Main Area */}
            <div className="main-wrapper">
                {/* Header */}
                <TopBar
                    searchQuery={searchQuery}
                    onSearchChange={setSearchQuery}
                    showSearch={projects.length > 0}
                    brandTitle="Issue Tracking System"
                />

                <div className="content-body">
                    {/* No Projects Available Screen (PDF Page 5) */}
                    {!loading && projects.length === 0 ? (
                        <div className="text-center py-5 my-5">
                            <h3 className="text-danger fw-bold mb-4">No Projects Available !</h3>
                            <Link to="/create-project" className="btn btn-outline-warning px-4 py-2 fw-semibold">
                                Create Project
                            </Link>
                        </div>
                    ) : (
                        <>
                            {/* Dashboard Heading */}
                            <h5 className="fw-bold text-dark mb-3" style={{ letterSpacing: '0.5px' }}>
                                PROJECT DASHBOARD
                            </h5>

                            {/* Project Selector & Owner Row */}
                            <div className="card border-0 shadow-sm mb-3 bg-white p-3 rounded">
                                <div className="row g-3 align-items-center">
                                    <div className="col-md-6">
                                        <label className="form-label text-muted small mb-1 fw-semibold">Project Name</label>
                                        <select
                                            className="form-select"
                                            value={selectedProjectId || ''}
                                            onChange={(e) => setSelectedProjectId(Number(e.target.value))}
                                        >
                                            {projects.map(proj => (
                                                <option key={proj.id} value={proj.id}>
                                                    {proj.projectName}
                                                </option>
                                            ))}
                                        </select>
                                    </div>

                                    <div className="col-md-6 text-md-end pt-md-3">
                                        <span className="text-muted small fw-semibold">Project Owner Name: </span>
                                        <span className="fw-bold text-dark">
                                            {user?.name ? user.name.toUpperCase() : 'PROJECT OWNER'}
                                        </span>
                                    </div>
                                </div>

                                {/* Start & End Date Line (dd-mm-yyyy) */}
                                {currentProject && (
                                    <div className="mt-3 text-muted small border-top pt-2">
                                        <span className="fw-semibold">Start Date: </span>
                                        <span>{formatDate(currentProject.startDate)}</span>
                                        <span className="mx-2">|</span>
                                        <span className="fw-semibold">End Date: </span>
                                        <span>{formatDate(currentProject.endDate)}</span>
                                    </div>
                                )}
                            </div>

                            {/* Filter Bar */}
                            <div className="row g-3 mb-3">
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Filter by Assignee</label>
                                    <select
                                        className="form-select form-select-sm"
                                        value={selectedAssignee}
                                        onChange={(e) => setSelectedAssignee(e.target.value)}
                                    >
                                        <option value="ALL">All</option>
                                        {projectAssignees.map(a => (
                                            <option key={a.userId} value={a.userId}>
                                                {a.name}
                                            </option>
                                        ))}
                                    </select>
                                </div>

                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Filter by Priority</label>
                                    <select
                                        className="form-select form-select-sm"
                                        value={selectedPriority}
                                        onChange={(e) => setSelectedPriority(e.target.value)}
                                    >
                                        <option value="ALL">All</option>
                                        <option value="LOW">Low</option>
                                        <option value="MEDIUM">Medium</option>
                                        <option value="HIGH">High</option>
                                    </select>
                                </div>
                            </div>

                            {/* Kanban Board with 4 Columns */}
                            <div className="kanban-grid">
                                {/* TO-DO Column */}
                                <div className="kanban-column column-todo">
                                    <div className="kanban-header">
                                        <span>📋 TO DO</span>
                                        <span className="badge-count badge-count-todo">{todoIssues.length}</span>
                                    </div>
                                    <div className="kanban-cards">
                                        {todoIssues.map(issue => (
                                            <IssueCard
                                                key={issue.id}
                                                issue={issue}
                                                assigneeUser={usersMap[issue.assignee]}
                                                onClick={handleCardClick}
                                            />
                                        ))}
                                    </div>
                                </div>

                                {/* DEVELOPMENT Column */}
                                <div className="kanban-column column-dev">
                                    <div className="kanban-header">
                                        <span>&lt;/&gt; DEVELOPMENT</span>
                                        <span className="badge-count badge-count-dev">{devIssues.length}</span>
                                    </div>
                                    <div className="kanban-cards">
                                        {devIssues.map(issue => (
                                            <IssueCard
                                                key={issue.id}
                                                issue={issue}
                                                assigneeUser={usersMap[issue.assignee]}
                                                onClick={handleCardClick}
                                            />
                                        ))}
                                    </div>
                                </div>

                                {/* TESTING Column */}
                                <div className="kanban-column column-test">
                                    <div className="kanban-header">
                                        <span>🗂️ TESTING</span>
                                        <span className="badge-count badge-count-test">{testIssues.length}</span>
                                    </div>
                                    <div className="kanban-cards">
                                        {testIssues.map(issue => (
                                            <IssueCard
                                                key={issue.id}
                                                issue={issue}
                                                assigneeUser={usersMap[issue.assignee]}
                                                onClick={handleCardClick}
                                            />
                                        ))}
                                    </div>
                                </div>

                                {/* COMPLETED Column */}
                                <div className="kanban-column column-done">
                                    <div className="kanban-header">
                                        <span>✅ COMPLETED</span>
                                        <span className="badge-count badge-count-done">{doneIssues.length}</span>
                                    </div>
                                    <div className="kanban-cards">
                                        {doneIssues.map(issue => (
                                            <IssueCard
                                                key={issue.id}
                                                issue={issue}
                                                assigneeUser={usersMap[issue.assignee]}
                                                onClick={handleCardClick}
                                            />
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
}

export default ProjectOwnerDashboard;
