import { useContext, useEffect, useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import Sidebar from "./Sidebar";
import TopBar from "./TopBar";
import IssueCard from "./IssueCard";
import { getIssuesByAssigneeId } from "../services/issueService";

/**
 * AssigneeDashboard Component
 * - Header with Application Name on right and Search bar on left
 * - Search bar filters out issue results based on matching RegEx between search text & summary/description
 * - Sidebar shows profile, email, count of issues assigned, and Logout button
 * - Issues displayed in 4 categories: TO-DO, Development, Testing, Completed
 * - Clicking any issue card navigates to Assignee Issue Details screen
 */
function AssigneeDashboard() {
    const { user } = useContext(AuthContext);
    const navigate = useNavigate();

    const [issues, setIssues] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [loading, setLoading] = useState(true);

    // Fetch issues assigned to current user
    useEffect(() => {
        const fetchAssignedIssues = async () => {
            if (!user?.userId) return;
            setLoading(true);
            try {
                const assigned = await getIssuesByAssigneeId(user.userId);
                setIssues(Array.isArray(assigned) ? assigned : []);
            } catch (err) {
                console.error('Error fetching assigned issues:', err);
                setIssues([]);
            } finally {
                setLoading(false);
            }
        };

        fetchAssignedIssues();
    }, [user]);

    // RegEx search filter matching summary or description
    const filteredIssues = useMemo(() => {
        if (!searchQuery.trim()) return issues;

        return issues.filter(issue => {
            try {
                const regex = new RegExp(searchQuery.trim(), 'i');
                return regex.test(issue.summary || '') || regex.test(issue.description || '');
            } catch {
                const q = searchQuery.toLowerCase();
                return (
                    (issue.summary || '').toLowerCase().includes(q) ||
                    (issue.description || '').toLowerCase().includes(q)
                );
            }
        });
    }, [issues, searchQuery]);

    // 4 Kanban Categories
    const todoIssues = useMemo(() => {
        return filteredIssues.filter(i => {
            const s = (i.status || '').toUpperCase();
            return s === 'TO_DO' || s === 'TO-DO' || s === '1';
        });
    }, [filteredIssues]);

    const devIssues = useMemo(() => {
        return filteredIssues.filter(i => {
            const s = (i.status || '').toUpperCase();
            return s === 'DEVELOPMENT' || s === 'IN_PROGRESS' || s === '2';
        });
    }, [filteredIssues]);

    const testIssues = useMemo(() => {
        return filteredIssues.filter(i => {
            const s = (i.status || '').toUpperCase();
            return s === 'TESTING' || s === '3';
        });
    }, [filteredIssues]);

    const doneIssues = useMemo(() => {
        return filteredIssues.filter(i => {
            const s = (i.status || '').toUpperCase();
            return s === 'DONE' || s === 'COMPLETED' || s === '4';
        });
    }, [filteredIssues]);

    // Card click navigates to Assignee Issue Details screen
    const handleCardClick = (issue) => {
        navigate(`/assignee-issue-details/${issue.id}`);
    };

    return (
        <div className="dashboard-layout">
            <Sidebar />

            <div className="main-wrapper">
                <TopBar
                    searchQuery={searchQuery}
                    onSearchChange={setSearchQuery}
                    showSearch={true}
                    brandTitle="Issue Tracking System"
                />

                <div className="content-body">
                    {loading ? (
                        <div className="text-center py-5">
                            <div className="spinner-border text-warning" role="status"></div>
                        </div>
                    ) : (
                        <div className="kanban-grid">
                            {/* TO DO Column */}
                            <div className="kanban-column column-todo">
                                <div className="kanban-header">
                                    <span>📋 TO DO</span>
                                    <span className="badge-count badge-count-todo">{todoIssues.length}</span>
                                </div>
                                <div className="kanban-cards">
                                    {todoIssues.map(issue => (
                                        <IssueCard
                                            key={issue.id}
                                            issue={issue}
                                            assigneeUser={user}
                                            onClick={handleCardClick}
                                        />
                                    ))}
                                </div>
                            </div>

                            {/* DEVELOPMENT Column */}
                            <div className="kanban-column column-dev">
                                <div className="kanban-header">
                                    <span>&lt;/&gt; DEVELOPMENT</span>
                                    <span className="badge-count badge-count-dev">{devIssues.length}</span>
                                </div>
                                <div className="kanban-cards">
                                    {devIssues.map(issue => (
                                        <IssueCard
                                            key={issue.id}
                                            issue={issue}
                                            assigneeUser={user}
                                            onClick={handleCardClick}
                                        />
                                    ))}
                                </div>
                            </div>

                            {/* TESTING Column */}
                            <div className="kanban-column column-test">
                                <div className="kanban-header">
                                    <span>🗂️ TESTING</span>
                                    <span className="badge-count badge-count-test">{testIssues.length}</span>
                                </div>
                                <div className="kanban-cards">
                                    {testIssues.map(issue => (
                                        <IssueCard
                                            key={issue.id}
                                            issue={issue}
                                            assigneeUser={user}
                                            onClick={handleCardClick}
                                        />
                                    ))}
                                </div>
                            </div>

                            {/* COMPLETED Column */}
                            <div className="kanban-column column-done">
                                <div className="kanban-header">
                                    <span>✅ COMPLETED</span>
                                    <span className="badge-count badge-count-done">{doneIssues.length}</span>
                                </div>
                                <div className="kanban-cards">
                                    {doneIssues.map(issue => (
                                        <IssueCard
                                            key={issue.id}
                                            issue={issue}
                                            assigneeUser={user}
                                            onClick={handleCardClick}
                                        />
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

export default AssigneeDashboard;
