import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Sidebar from "./Sidebar";
import TopBar from "./TopBar";
import { getIssueById, updateIssue } from "../services/issueService";
import { getAllProjects } from "../services/projectService";
import { getAllUsers } from "../services/userService";

/**
 * EditIssueForm Component (Project Owner)
 */
function EditIssueForm() {
    const { issueId } = useParams();
    const navigate = useNavigate();

    // Initial issue snapshot for reset
    const [initialData, setInitialData] = useState(null);

    // Form fields
    const [summary, setSummary] = useState('');
    const [type, setType] = useState('TASK');
    const [project, setProject] = useState('');
    const [priority, setPriority] = useState('MEDIUM');
    const [description, setDescription] = useState('');
    const [assignee, setAssignee] = useState('');
    const [tags, setTags] = useState('');
    const [sprint, setSprint] = useState('1');
    const [storyPoint, setStoryPoint] = useState('2');
    const [status, setStatus] = useState('TO_DO');

    // Predefined lists
    const [projectList, setProjectList] = useState([]);
    const [userList, setUserList] = useState([]);

    // Validation & loading states
    const [touched, setTouched] = useState({});
    const [errors, setErrors] = useState({});
    const [serverError, setServerError] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [loading, setLoading] = useState(true);

    // Load issue data and dropdown options
    useEffect(() => {
        const loadInitialData = async () => {
            setLoading(true);
            try {
                // Fetch projects
                const projects = await getAllProjects();
                setProjectList(Array.isArray(projects) ? projects : []);

                // Fetch users
                const users = await getAllUsers();
                setUserList(Array.isArray(users) ? users : []);

                // Fetch current issue
                const issueData = await getIssueById(issueId);
                if (issueData) {
                    setInitialData(issueData);
                    setSummary(issueData.summary || '');
                    setType(issueData.type || 'TASK');
                    setProject(String(issueData.project || ''));
                    setPriority(issueData.priority || 'MEDIUM');
                    setDescription(issueData.description || '');
                    setAssignee(String(issueData.assignee || ''));
                    setTags(issueData.tags || '');
                    setSprint(String(issueData.sprint || '1'));
                    setStoryPoint(String(issueData.storyPoint || '2'));
                    setStatus(issueData.status || 'TO_DO');
                }
            } catch (err) {
                console.error('Error loading issue for edit:', err);
                setServerError('Failed to load issue details.');
            } finally {
                setLoading(false);
            }
        };

        if (issueId) {
            loadInitialData();
        }
    }, [issueId]);

    // Validation rules from PDF Pages 8 & 9
    const validateSummary = (val) => {
        if (!val || !val.trim()) return 'Summary is required.';
        if (val.trim().length < 5) return 'Summary must be at least 5 characters.';
        if (val.length > 100) return 'Summary cannot exceed 100 characters.';
        return '';
    };

    const validateProject = (val) => (!val ? 'Project is required.' : '');
    const validateType = (val) => (!val ? 'Type is required.' : '');
    const validatePriority = (val) => (!val ? 'Priority is required.' : '');

    const validateDescription = (val) => {
        if (!val || !val.trim()) return 'Description is required.';
        if (val.trim().length < 10) return 'Description must be at least 10 characters.';
        if (val.length > 500) return 'Description cannot exceed 500 characters.';
        return '';
    };

    const validateAssignee = (val) => (!val ? 'Assignee is required.' : '');

    const validateSprint = (val) => {
        if (!val) return 'Sprint is required.';
        if (!/^[1-9]\d*$/.test(String(val))) return 'Sprint must be a positive integer.';
        return '';
    };

    const validateStoryPoint = (val) => {
        if (!val) return 'Story Point is required.';
        if (!/^[1-9]\d*$/.test(String(val))) return 'Story Point must be a positive integer.';
        return '';
    };

    const validateStatus = (val) => (!val ? 'Status is required.' : '');

    // Overall form validity check
    const isFormValid = () => {
        return (
            !validateSummary(summary) &&
            !validateProject(project) &&
            !validateType(type) &&
            !validatePriority(priority) &&
            !validateDescription(description) &&
            !validateAssignee(assignee) &&
            !validateSprint(sprint) &&
            !validateStoryPoint(storyPoint) &&
            !validateStatus(status)
        );
    };

    const handleBlur = (field) => {
        setTouched(prev => ({ ...prev, [field]: true }));
        validateField(field);
    };

    const validateField = (field) => {
        let err = '';
        switch (field) {
            case 'summary': err = validateSummary(summary); break;
            case 'project': err = validateProject(project); break;
            case 'type': err = validateType(type); break;
            case 'priority': err = validatePriority(priority); break;
            case 'description': err = validateDescription(description); break;
            case 'assignee': err = validateAssignee(assignee); break;
            case 'sprint': err = validateSprint(sprint); break;
            case 'storyPoint': err = validateStoryPoint(storyPoint); break;
            case 'status': err = validateStatus(status); break;
            default: break;
        }
        setErrors(prev => ({ ...prev, [field]: err }));
    };

    // Reset button resets form to initial state
    const handleReset = () => {
        if (initialData) {
            setSummary(initialData.summary || '');
            setType(initialData.type || 'TASK');
            setProject(String(initialData.project || ''));
            setPriority(initialData.priority || 'MEDIUM');
            setDescription(initialData.description || '');
            setAssignee(String(initialData.assignee || ''));
            setTags(initialData.tags || '');
            setSprint(String(initialData.sprint || '1'));
            setStoryPoint(String(initialData.storyPoint || '2'));
            setStatus(initialData.status || 'TO_DO');
            setTouched({});
            setErrors({});
            setServerError('');
        }
    };

    // Handle Edit form submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        setServerError('');

        const allErrors = {
            summary: validateSummary(summary),
            project: validateProject(project),
            type: validateType(type),
            priority: validatePriority(priority),
            description: validateDescription(description),
            assignee: validateAssignee(assignee),
            sprint: validateSprint(sprint),
            storyPoint: validateStoryPoint(storyPoint),
            status: validateStatus(status)
        };

        const allTouched = Object.keys(allErrors).reduce((acc, k) => ({ ...acc, [k]: true }), {});
        setTouched(allTouched);
        setErrors(allErrors);

        if (Object.values(allErrors).some(err => err)) {
            return;
        }

        setIsSubmitting(true);
        try {
            const updatedIssue = {
                ...initialData,
                summary: summary.trim(),
                description: description.trim(),
                project: Number(project),
                assignee: Number(assignee),
                sprint: String(sprint),
                storyPoint: Number(storyPoint),
                tags: tags.trim(),
                priority,
                status,
                type: type === 'FEATURE' ? 'TASK' : type
            };

            await updateIssue(issueId, updatedIssue);
            // On Success, redirect to issue details
            navigate(`/issue-details/${issueId}`);
        } catch (err) {
            console.error('Failed to update issue:', err);
            setServerError(err.response?.data?.message || err.message || 'Server error updating issue.');
        } finally {
            setIsSubmitting(false);
        }
    };

    if (loading) {
        return (
            <div className="dashboard-layout">
                <Sidebar />
                <div className="main-wrapper">
                    <TopBar showSearch={false} />
                    <div className="content-body text-center py-5">
                        <div className="spinner-border text-warning" role="status"></div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="dashboard-layout">
            <Sidebar />

            <div className="main-wrapper">
                <TopBar showSearch={false} brandTitle="Deloitte Engineering" />

                <div className="content-body">
                    <h5 className="fw-bold text-dark mb-4" style={{ letterSpacing: '0.5px' }}>
                        Edit Issue
                    </h5>

                    {serverError && (
                        <div className="alert alert-danger py-2" role="alert">
                            {serverError}
                        </div>
                    )}

                    <div className="form-card">
                        <form onSubmit={handleSubmit} noValidate>
                            <div className="row g-3">
                                {/* Summary */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Summary</label>
                                    <input
                                        type="text"
                                        maxLength={100}
                                        className={`form-control ${touched.summary && errors.summary ? 'is-invalid' : ''}`}
                                        value={summary}
                                        onChange={(e) => setSummary(e.target.value)}
                                        onBlur={() => handleBlur('summary')}
                                    />
                                    {touched.summary && errors.summary && (
                                        <div className="invalid-feedback">{errors.summary}</div>
                                    )}
                                </div>

                                {/* Type */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Type</label>
                                    <select
                                        className={`form-select ${touched.type && errors.type ? 'is-invalid' : ''}`}
                                        value={type}
                                        onChange={(e) => setType(e.target.value)}
                                        onBlur={() => handleBlur('type')}
                                    >
                                        <option value="TASK">TASK</option>
                                        <option value="BUG">BUG</option>
                                        <option value="FEATURE">FEATURE</option>
                                    </select>
                                    {touched.type && errors.type && (
                                        <div className="invalid-feedback">{errors.type}</div>
                                    )}
                                </div>

                                {/* Project */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Project</label>
                                    <select
                                        className={`form-select ${touched.project && errors.project ? 'is-invalid' : ''}`}
                                        value={project}
                                        onChange={(e) => setProject(e.target.value)}
                                        onBlur={() => handleBlur('project')}
                                    >
                                        <option value="">Select project</option>
                                        {projectList.map(p => (
                                            <option key={p.id} value={p.id}>
                                                {p.projectName}
                                            </option>
                                        ))}
                                    </select>
                                    {touched.project && errors.project && (
                                        <div className="invalid-feedback">{errors.project}</div>
                                    )}
                                </div>

                                {/* Priority */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Priority</label>
                                    <select
                                        className={`form-select ${touched.priority && errors.priority ? 'is-invalid' : ''}`}
                                        value={priority}
                                        onChange={(e) => setPriority(e.target.value)}
                                        onBlur={() => handleBlur('priority')}
                                    >
                                        <option value="LOW">LOW</option>
                                        <option value="MEDIUM">MEDIUM</option>
                                        <option value="HIGH">HIGH</option>
                                    </select>
                                    {touched.priority && errors.priority && (
                                        <div className="invalid-feedback">{errors.priority}</div>
                                    )}
                                </div>

                                {/* Description */}
                                <div className="col-12">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Description</label>
                                    <textarea
                                        rows={3}
                                        maxLength={500}
                                        className={`form-control ${touched.description && errors.description ? 'is-invalid' : ''}`}
                                        value={description}
                                        onChange={(e) => setDescription(e.target.value)}
                                        onBlur={() => handleBlur('description')}
                                    />
                                    {touched.description && errors.description && (
                                        <div className="invalid-feedback">{errors.description}</div>
                                    )}
                                </div>

                                {/* Assignee */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Assignee</label>
                                    <select
                                        className={`form-select ${touched.assignee && errors.assignee ? 'is-invalid' : ''}`}
                                        value={assignee}
                                        onChange={(e) => setAssignee(e.target.value)}
                                        onBlur={() => handleBlur('assignee')}
                                    >
                                        <option value="">Select assignee</option>
                                        {userList.map(u => (
                                            <option key={u.userId} value={u.userId}>
                                                {u.name}
                                            </option>
                                        ))}
                                    </select>
                                    {touched.assignee && errors.assignee && (
                                        <div className="invalid-feedback">{errors.assignee}</div>
                                    )}
                                </div>

                                {/* Tags */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Tags</label>
                                    <input
                                        type="text"
                                        maxLength={100}
                                        className="form-control"
                                        value={tags}
                                        onChange={(e) => setTags(e.target.value)}
                                    />
                                </div>

                                {/* Sprint */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Sprint</label>
                                    <input
                                        type="number"
                                        min={1}
                                        className={`form-control ${touched.sprint && errors.sprint ? 'is-invalid' : ''}`}
                                        value={sprint}
                                        onChange={(e) => setSprint(e.target.value)}
                                        onBlur={() => handleBlur('sprint')}
                                    />
                                    {touched.sprint && errors.sprint && (
                                        <div className="invalid-feedback">{errors.sprint}</div>
                                    )}
                                </div>

                                {/* Story Point */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Story Point</label>
                                    <input
                                        type="number"
                                        min={1}
                                        className={`form-control ${touched.storyPoint && errors.storyPoint ? 'is-invalid' : ''}`}
                                        value={storyPoint}
                                        onChange={(e) => setStoryPoint(e.target.value)}
                                        onBlur={() => handleBlur('storyPoint')}
                                    />
                                    {touched.storyPoint && errors.storyPoint && (
                                        <div className="invalid-feedback">{errors.storyPoint}</div>
                                    )}
                                </div>

                                {/* Status */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Status</label>
                                    <select
                                        className={`form-select ${touched.status && errors.status ? 'is-invalid' : ''}`}
                                        value={status}
                                        onChange={(e) => setStatus(e.target.value)}
                                        onBlur={() => handleBlur('status')}
                                    >
                                        <option value="TO_DO">TO_DO</option>
                                        <option value="DEVELOPMENT">DEVELOPMENT</option>
                                        <option value="TESTING">TESTING</option>
                                        <option value="DONE">DONE</option>
                                    </select>
                                    {touched.status && errors.status && (
                                        <div className="invalid-feedback">{errors.status}</div>
                                    )}
                                </div>
                            </div>

                            {/* Action Buttons: EDIT and RESET */}
                            <div className="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                                <button
                                    type="submit"
                                    className="btn btn-warning px-4 fw-semibold text-uppercase"
                                    disabled={!isFormValid() || isSubmitting}
                                >
                                    {isSubmitting ? 'Saving...' : 'EDIT'}
                                </button>
                                <button
                                    type="button"
                                    className="btn btn-outline-secondary px-4 fw-semibold text-uppercase"
                                    onClick={handleReset}
                                    disabled={isSubmitting}
                                >
                                    RESET
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default EditIssueForm;
