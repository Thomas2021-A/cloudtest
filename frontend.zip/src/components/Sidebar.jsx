import { useContext, useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { getProjectsByOwner } from "../services/projectService";
import { getIssuesByOwnerId, getIssuesByAssigneeId } from "../services/issueService";

/**
 * Sidebar Component
 * Appears on all authenticated screens:
 * - Profile avatar, user name, and email address
 * - Live stats:
 *     - Project Owner: Number of Projects Created & Issues Created
 *     - Assignee: Number of Issues Assigned
 * - Navigation links: Project Dashboard, Create Project, Create Issue
 * - Logout button
 */
function Sidebar() {
    const { user, ctxLogout } = useContext(AuthContext);
    const location = useLocation();
    const navigate = useNavigate();

    const [projectsCount, setProjectsCount] = useState(0);
    const [issuesCount, setIssuesCount] = useState(0);

    const isProjectOwner = user?.role === 'PROJECT_OWNER' || user?.role === 'Project Owner';

    useEffect(() => {
        const loadStats = async () => {
            if (!user?.userId) return;

            try {
                if (isProjectOwner) {
                    const projects = await getProjectsByOwner(user.userId);
                    setProjectsCount(Array.isArray(projects) ? projects.length : 0);

                    const issues = await getIssuesByOwnerId(user.userId);
                    setIssuesCount(Array.isArray(issues) ? issues.length : 0);
                } else {
                    const assignedIssues = await getIssuesByAssigneeId(user.userId);
                    setIssuesCount(Array.isArray(assignedIssues) ? assignedIssues.length : 0);
                }
            } catch (err) {
                console.warn('Error loading sidebar stats:', err);
            }
        };

        loadStats();
    }, [user, isProjectOwner, location.pathname]);

    const handleLogout = () => {
        ctxLogout();
        navigate('/login');
    };

    // Default avatar if none provided
    const avatarUrl = user?.profileImage && user.profileImage.trim() !== ''
        ? user.profileImage
        : 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150';

    return (
        <aside className="sidebar">
            {/* User Profile Section */}
            <div className="sidebar-profile">
                <img
                    src={avatarUrl}
                    alt={user?.name || 'User Avatar'}
                    className="profile-avatar"
                    onError={(e) => {
                        e.target.src = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150';
                    }}
                />
                <h6>{user?.name || 'User Name'}</h6>
                <p>{user?.emailId || 'user@xyz.com'}</p>

                {/* Counters */}
                <div className="sidebar-stats">
                    {isProjectOwner ? (
                        <>
                            <div className="stat-item">
                                <span className="stat-num">{projectsCount}</span>
                                <span className="stat-label">Projects<br />Created</span>
                            </div>
                            <div className="stat-item">
                                <span className="stat-num">{issuesCount}</span>
                                <span className="stat-label">Issues<br />Created</span>
                            </div>
                        </>
                    ) : (
                        <div className="stat-item w-100">
                            <span className="stat-num">{issuesCount}</span>
                            <span className="stat-label">Issues Assigned</span>
                        </div>
                    )}
                </div>
            </div>

            {/* Navigation Links */}
            <ul className="sidebar-nav">
                {isProjectOwner ? (
                    <>
                        <li>
                            <Link
                                to="/project-dashboard"
                                className={location.pathname === '/project-dashboard' || location.pathname === '/' ? 'active' : ''}
                            >
                                <span style={{ color: '#f5a623' }}>📁</span> Project Dashboard
                            </Link>
                        </li>
                        <li>
                            <Link
                                to="/create-project"
                                className={location.pathname === '/create-project' ? 'active' : ''}
                            >
                                <span style={{ color: '#f5a623' }}>➕</span> Create Project
                            </Link>
                        </li>
                        <li>
                            <Link
                                to="/create-issue"
                                className={location.pathname === '/create-issue' ? 'active' : ''}
                            >
                                <span style={{ color: '#f5a623' }}>➕</span> Create Issue
                            </Link>
                        </li>
                    </>
                ) : (
                    <li>
                        <Link
                            to="/assignee-dashboard"
                            className={location.pathname === '/assignee-dashboard' || location.pathname === '/' ? 'active' : ''}
                        >
                            <span style={{ color: '#f5a623' }}>📁</span> Assignee Dashboard
                        </Link>
                    </li>
                )}
            </ul>

            {/* Logout Button */}
            <div className="sidebar-footer">
                <button className="btn-sidebar-logout" onClick={handleLogout}>
                    <span>↪</span> Logout
                </button>
            </div>
        </aside>
    );
}

export default Sidebar;
