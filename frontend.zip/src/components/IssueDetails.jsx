import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import Sidebar from "./Sidebar";
import TopBar from "./TopBar";
import { getIssueById } from "../services/issueService";
import { getUserById } from "../services/userService";

/**
 * IssueDetails Component (Project Owner View) 
 * - Breadcrumb: Project Board / Issue Details 
 * - "Edit Issue" button in top-right
 * - Description display
 * - Details breakdown: Type, Tags (green badge), Story Points
 * - Status, Assignee, Sprint, Priority, Created On, Last Updated
 */
function IssueDetails() {
    const { issueId } = useParams();
    const navigate = useNavigate();

    const [issue, setIssue] = useState(null);
    const [assigneeUser, setAssigneeUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchIssue = async () => {
            setLoading(true);
            try {
                const data = await getIssueById(issueId);
                setIssue(data);

                if (data?.assignee) {
                    const user = await getUserById(data.assignee);
                    setAssigneeUser(user);
                }
            } catch (err) {
                console.error('Error fetching issue details:', err);
            } finally {
                setLoading(false);
            }
        };

        if (issueId) {
            fetchIssue();
        }
    }, [issueId]);

    // Format date string to dd-mm-yyyy
    const formatDate = (dateStr) => {
        if (!dateStr) return '';
        if (/^\d{2}-\d{2}-\d{4}/.test(dateStr)) return dateStr;
        const parts = dateStr.split('-');
        if (parts.length === 3) {
            return `${parts[2]}-${parts[1]}-${parts[0]}`;
        }
        return dateStr;
    };

    if (loading) {
        return (
            <div className="dashboard-layout">
                <Sidebar />
                <div className="main-wrapper">
                    <TopBar showSearch={false} />
                    <div className="content-body text-center py-5">
                        <div className="spinner-border text-warning" role="status"></div>
                    </div>
                </div>
            </div>
        );
    }

    if (!issue) {
        return (
            <div className="dashboard-layout">
                <Sidebar />
                <div className="main-wrapper">
                    <TopBar showSearch={false} />
                    <div className="content-body text-center py-5">
                        <h4 className="text-danger">Issue not found</h4>
                        <Link to="/project-dashboard" className="btn btn-warning mt-3">
                            Back to Project Board
                        </Link>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="dashboard-layout">
            <Sidebar />

            <div className="main-wrapper">
                <TopBar showSearch={false} brandTitle="Issue Tracking System" />

                <div className="content-body">
                    {/* Breadcrumb */}
                    <div className="mb-3 small">
                        <Link to="/project-dashboard" className="text-secondary text-decoration-none">
                            Project Board
                        </Link>
                        <span className="text-muted mx-2">/</span>
                        <span className="text-muted">Issue Details</span>
                    </div>

                    <div className="card border-0 shadow-sm p-4 bg-white" style={{ borderRadius: '8px' }}>
                        {/* Title Row with Edit Issue Button */}
                        <div className="d-flex justify-content-between align-items-start mb-3">
                            <h2 className="issue-detail-title mb-0">
                                {issue.summary}
                            </h2>
                            <button
                                className="btn btn-dark btn-sm px-3 py-2 fw-semibold"
                                onClick={() => navigate(`/edit-issue/${issue.id}`)}
                            >
                                Edit Issue
                            </button>
                        </div>

                        {/* Description Section */}
                        <div className="mb-4">
                            <h6 className="fw-semibold text-secondary mb-1">Description :</h6>
                            <p className="text-dark" style={{ lineHeight: '1.6' }}>
                                {issue.description || 'No description provided.'}
                            </p>
                        </div>

                        {/* Two Column Layout for Details */}
                        <div className="row g-4 pt-3 border-top">
                            {/* Left Column: Details */}
                            <div className="col-md-6">
                                <h6 className="fw-bold text-dark mb-3">Details</h6>
                                <div className="mb-2">
                                    <span className="fw-semibold text-muted">Type: </span>
                                    <span className="text-dark fw-medium">{issue.type}</span>
                                </div>

                                {issue.tags && (
                                    <div className="mb-2">
                                        <span className="fw-semibold text-muted">Tags: </span>
                                        <span className="tag-badge">{issue.tags}</span>
                                    </div>
                                )}

                                <div className="mb-2">
                                    <span className="fw-semibold text-muted">Story Points: </span>
                                    <span className="text-dark fw-medium">{issue.storyPoint}</span>
                                </div>
                            </div>

                            {/* Right Column: Status & Metadata */}
                            <div className="col-md-6">
                                <div className="mb-2">
                                    <span className="fw-semibold text-muted">Status: </span>
                                    <span className="fw-bold text-success">{issue.status}</span>
                                </div>

                                <div className="mb-2">
                                    <span className="fw-semibold text-muted">Assignee: </span>
                                    <span className="text-info fw-semibold">
                                        {assigneeUser?.name || `Assignee #${issue.assignee}`}
                                    </span>
                                </div>

                                <div className="mb-2">
                                    <span className="fw-semibold text-muted">Sprint: </span>
                                    <span className="text-dark">{issue.sprint}</span>
                                </div>

                                <div className="mb-2">
                                    <span className="fw-semibold text-muted">Priority: </span>
                                    <span className="text-dark">{issue.priority}</span>
                                </div>

                                <div className="mb-2">
                                    <span className="fw-semibold text-muted">Created On: </span>
                                    <span className="text-dark">{formatDate(issue.createdOn)}</span>
                                </div>

                                <div className="mb-2">
                                    <span className="fw-semibold text-muted">Last Updated: </span>
                                    <span className="text-dark">{issue.lastUpdated || formatDate(issue.createdOn)}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default IssueDetails;
