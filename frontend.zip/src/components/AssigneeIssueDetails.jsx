import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import Sidebar from "./Sidebar";
import TopBar from "./TopBar";
import { getIssueById, updateIssue } from "../services/issueService";

/**
 * AssigneeIssueDetails Component
 * - Displayed when clicking any issue card from Assignee Dashboard
 * - Breadcrumb: Issue Dashboard / Issue Details
 * - Title, Description, Type, Tags, Story Points, Sprint, Priority
 * - Status dropdown menu for changing issue status
 * - "Save Updates" button:
 *     - Only becomes enabled when the status is changed using the drop-down!
 *     - Clicking "Save Updates" updates the issue's status accordingly.
 */
function AssigneeIssueDetails() {
    const { issueId } = useParams();
    const navigate = useNavigate();

    const [issue, setIssue] = useState(null);
    const [originalStatus, setOriginalStatus] = useState('');
    const [selectedStatus, setSelectedStatus] = useState('');
    const [loading, setLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [successMessage, setSuccessMessage] = useState('');
    const [errorMessage, setErrorMessage] = useState('');

    useEffect(() => {
        const fetchIssue = async () => {
            setLoading(true);
            try {
                const data = await getIssueById(issueId);
                if (data) {
                    setIssue(data);
                    setOriginalStatus(data.status || 'TO_DO');
                    setSelectedStatus(data.status || 'TO_DO');
                }
            } catch (err) {
                console.error('Error fetching issue:', err);
                setErrorMessage('Failed to load issue details.');
            } finally {
                setLoading(false);
            }
        };

        if (issueId) {
            fetchIssue();
        }
    }, [issueId]);

    // Check if status has been changed to enable Save Updates button
    const hasStatusChanged = selectedStatus !== originalStatus;

    // Handle Save Updates click
    const handleSaveUpdates = async () => {
        if (!hasStatusChanged || isSaving) return;

        setIsSaving(true);
        setSuccessMessage('');
        setErrorMessage('');

        try {
            const updated = {
                ...issue,
                status: selectedStatus
            };

            await updateIssue(issueId, updated);
            setOriginalStatus(selectedStatus);
            setIssue(updated);
            setSuccessMessage('Status updated successfully!');

            // Return to dashboard after short delay or stay
            setTimeout(() => {
                navigate('/assignee-dashboard');
            }, 1200);
        } catch (err) {
            console.error('Error updating status:', err);
            setErrorMessage(err.response?.data?.message || err.message || 'Failed to update issue status.');
        } finally {
            setIsSaving(false);
        }
    };

    if (loading) {
        return (
            <div className="dashboard-layout">
                <Sidebar />
                <div className="main-wrapper">
                    <TopBar showSearch={false} />
                    <div className="content-body text-center py-5">
                        <div className="spinner-border text-warning" role="status"></div>
                    </div>
                </div>
            </div>
        );
    }

    if (!issue) {
        return (
            <div className="dashboard-layout">
                <Sidebar />
                <div className="main-wrapper">
                    <TopBar showSearch={false} />
                    <div className="content-body text-center py-5">
                        <h4 className="text-danger">Issue not found</h4>
                        <Link to="/assignee-dashboard" className="btn btn-warning mt-3">
                            Back to Assignee Dashboard
                        </Link>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="dashboard-layout">
            <Sidebar />

            <div className="main-wrapper">
                <TopBar showSearch={false} brandTitle="Issue Tracking System" />

                <div className="content-body">
                    {/* Breadcrumb */}
                    <div className="mb-3 small">
                        <Link to="/assignee-dashboard" className="text-secondary text-decoration-none">
                            Issue Dashboard
                        </Link>
                        <span className="text-muted mx-2">/</span>
                        <span className="text-muted">Issue Details</span>
                    </div>

                    {successMessage && (
                        <div className="alert alert-success py-2" role="alert">
                            {successMessage}
                        </div>
                    )}
                    {errorMessage && (
                        <div className="alert alert-danger py-2" role="alert">
                            {errorMessage}
                        </div>
                    )}

                    <div className="card border-0 shadow-sm p-4 bg-white" style={{ borderRadius: '8px' }}>
                        {/* Title */}
                        <h2 className="issue-detail-title mb-3">
                            {issue.summary}
                        </h2>

                        {/* Description Section */}
                        <div className="mb-4">
                            <h6 className="fw-semibold text-secondary mb-1">Description :</h6>
                            <p className="text-dark" style={{ lineHeight: '1.6' }}>
                                {issue.description || 'No description provided.'}
                            </p>
                        </div>

                        {/* Details and Status Section */}
                        <div className="row g-4 pt-3 border-top">
                            {/* Left Column: Details */}
                            <div className="col-md-6">
                                <h6 className="fw-bold text-dark mb-3">Details</h6>
                                <div className="mb-2">
                                    <span className="fw-semibold text-muted">Type: </span>
                                    <span className="text-dark fw-medium">{issue.type}</span>
                                </div>

                                {issue.tags && (
                                    <div className="mb-2">
                                        <span className="fw-semibold text-muted">Tags: </span>
                                        <span className="tag-badge">{issue.tags}</span>
                                    </div>
                                )}

                                <div className="mb-2">
                                    <span className="fw-semibold text-muted">Story Points: </span>
                                    <span className="text-dark fw-medium">{issue.storyPoint}</span>
                                </div>
                            </div>

                            {/* Right Column: Status Dropdown & Info */}
                            <div className="col-md-6">
                                <div className="mb-3">
                                    <label className="form-label fw-semibold text-muted mb-1">Status:</label>
                                    <select
                                        className="form-select w-75"
                                        value={selectedStatus}
                                        onChange={(e) => setSelectedStatus(e.target.value)}
                                    >
                                        <option value="TO_DO">TO-DO</option>
                                        <option value="DEVELOPMENT">DEVELOPMENT</option>
                                        <option value="TESTING">TESTING</option>
                                        <option value="DONE">COMPLETED</option>
                                    </select>
                                </div>

                                <div className="mb-2">
                                    <span className="fw-semibold text-muted">Sprint: </span>
                                    <span className="text-dark">{issue.sprint}</span>
                                </div>

                                <div className="mb-2">
                                    <span className="fw-semibold text-muted">Priority: </span>
                                    <span className="text-dark">{issue.priority}</span>
                                </div>
                            </div>
                        </div>

                        {/* Save Updates Button (Center or right aligned as per PDF Page 10) */}
                        <div className="text-center mt-4 pt-3 border-top">
                            <button
                                className="btn btn-warning px-4 py-2 fw-semibold"
                                disabled={!hasStatusChanged || isSaving}
                                onClick={handleSaveUpdates}
                            >
                                {isSaving ? 'Saving...' : 'Save Updates'}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default AssigneeIssueDetails;
