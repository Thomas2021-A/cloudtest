/**
 * IssueCard Component 
 * Shows: Id, Date (dd-mm-yyyy), Summary, Description, Assignee photo & name, Priority badge
 */
function IssueCard({ issue, assigneeUser, onClick }) {
    // Helper to format date to dd-mm-yyyy
    const formatDate = (dateStr) => {
        if (!dateStr) return '';
        // If already in dd-mm-yyyy format
        if (/^\d{2}-\d{2}-\d{4}/.test(dateStr)) {
            return dateStr.substring(0, 10);
        }
        // If yyyy-mm-dd
        const parts = dateStr.split('-');
        if (parts.length === 3) {
            return `${parts[2]}-${parts[1]}-${parts[0]}`;
        }
        return dateStr;
    };

    // Priority badge class
    const getPriorityBadgeClass = (priority) => {
        const p = (priority || '').toUpperCase();
        if (p === 'HIGH') return 'badge-priority-high';
        if (p === 'MEDIUM') return 'badge-priority-medium';
        return 'badge-priority-low';
    };

    const assigneeName = assigneeUser?.name || `Assignee #${issue.assignee || 'Unassigned'}`;
    const assigneeAvatar = assigneeUser?.profileImage || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150';

    return (
        <div className="kanban-card" onClick={() => onClick(issue)}>
            {/* Top row: ID and Date */}
            <div className="card-top-row">
                <span className="card-id">Id: {issue.id}</span>
                <span className="card-date">{formatDate(issue.createdOn)}</span>
            </div>

            {/* Summary Title */}
            <div className="card-summary">
                {issue.summary}
            </div>

            {/* Description */}
            <div className="card-desc">
                {issue.description || 'No description provided.'}
            </div>

            {/* Bottom Row: Assignee & Priority */}
            <div className="card-bottom-row">
                <div className="card-assignee">
                    <img
                        src={assigneeAvatar}
                        alt={assigneeName}
                        className="assignee-avatar-sm"
                        onError={(e) => {
                            e.target.src = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150';
                        }}
                    />
                    <span>{assigneeName}</span>
                </div>

                <span className={getPriorityBadgeClass(issue.priority)}>
                    {issue.priority ? issue.priority.charAt(0).toUpperCase() + issue.priority.slice(1).toLowerCase() : 'Low'}
                </span>
            </div>
        </div>
    );
}

export default IssueCard;
