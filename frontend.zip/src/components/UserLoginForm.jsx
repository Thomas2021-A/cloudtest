import { useContext, useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { login } from "../services/userService";
import { AuthContext } from "../context/AuthContext";

/**
 * UserLoginForm - Controlled Component Form
 * As required by PDF Page 4:
 * - Email & Password required and validated for format
 * - Role field required with 'Project Owner' and 'Assignee' options
 * - Submit button disabled if form is invalid
 * - Validation messages shown on interaction (handleBlur / handleChange)
 * - Navigation link to Signup page
 */
function UserLoginForm() {
    // Controlled form state
    const [form, setForm] = useState({
        userEmail: '',
        userPassword: '',
        role: ''
    });

    // Validation errors state
    const [fieldErrors, setFieldErrors] = useState({});
    const [touched, setTouched] = useState({});
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    const navigate = useNavigate();
    const { ctxLogin, user: loggedInUser } = useContext(AuthContext);

    // Reset form when logged out
    useEffect(() => {
        if (!loggedInUser) {
            setForm({ userEmail: '', userPassword: '', role: '' });
            setFieldErrors({});
            setTouched({});
            setError('');
            setSuccess('');
        }
    }, [loggedInUser]);

    // Field-level validator
    const getFieldError = (name, value) => {
        switch (name) {
            case 'userEmail':
                if (!value || !value.trim()) return 'Email address is required.';
                if (!/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(value.trim())) {
                    return 'Please enter a valid email address.';
                }
                break;
            case 'userPassword':
                if (!value) return 'Password is required.';
                if (value.length < 6) return 'Password must be at least 6 characters.';
                break;
            case 'role':
                if (!value) return 'Please select your role.';
                break;
            default:
                return '';
        }
        return '';
    };

    // Handle input changes
    const handleChange = (e) => {
        const { name, value } = e.target;
        setForm(prev => ({
            ...prev,
            [name]: value
        }));

        // If touched, re-validate dynamically
        if (touched[name]) {
            setFieldErrors(prev => ({
                ...prev,
                [name]: getFieldError(name, value)
            }));
        }
    };

    // Handle blur event
    const handleBlur = (e) => {
        const { name, value } = e.target;
        setTouched(prev => ({ ...prev, [name]: true }));
        setFieldErrors(prev => ({
            ...prev,
            [name]: getFieldError(name, value)
        }));
    };

    // Determine if form is completely valid
    const isFormValid = () => {
        const emailErr = getFieldError('userEmail', form.userEmail);
        const passErr = getFieldError('userPassword', form.userPassword);
        const roleErr = getFieldError('role', form.role);

        return (
            form.userEmail.trim() !== '' &&
            form.userPassword !== '' &&
            form.role !== '' &&
            !emailErr &&
            !passErr &&
            !roleErr
        );
    };

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        // Validate all fields
        const errors = {
            userEmail: getFieldError('userEmail', form.userEmail),
            userPassword: getFieldError('userPassword', form.userPassword),
            role: getFieldError('role', form.role)
        };

        setFieldErrors(errors);
        setTouched({ userEmail: true, userPassword: true, role: true });

        if (Object.values(errors).some(err => err)) {
            setError('Please correct the validation errors below.');
            return;
        }

        try {
            const result = await login(form.userEmail, form.userPassword, form.role);
            if (result.success && result.user) {
                ctxLogin(result.user);
                setSuccess('Logged in successfully!');

                // Redirect based on user role
                const userRole = result.user.role || form.role;
                if (userRole === 'PROJECT_OWNER' || userRole === 'Project Owner') {
                    navigate('/project-dashboard');
                } else {
                    navigate('/assignee-dashboard');
                }
            } else {
                setError(result.error || 'Invalid credentials. Please try again.');
            }
        } catch (err) {
            console.error('Login error:', err);
            setError(err.message || 'An unexpected error occurred during login.');
        }
    };

    return (
        <div className="container-fluid min-vh-100 d-flex justify-content-center align-items-center bg-light py-5">
            <div className="col-11 col-sm-9 col-md-6 col-lg-4">
                <div className="card shadow border-0" style={{ borderRadius: '8px', overflow: 'hidden' }}>
                    {/* Header Banner matching PDF Page 4 */}
                    <div className="auth-header-banner">
                        Issue Tracking System
                    </div>

                    <div className="card-body p-4 bg-white">
                        <h4 className="text-center mb-4 fw-normal text-secondary">Login</h4>

                        {error && (
                            <div className="alert alert-danger py-2" role="alert">
                                {error}
                            </div>
                        )}
                        {success && (
                            <div className="alert alert-success py-2" role="alert">
                                {success}
                            </div>
                        )}

                        <form onSubmit={handleSubmit} noValidate>
                            {/* Email Address */}
                            <div className="mb-3">
                                <label className="form-label text-muted small mb-1">Email address</label>
                                <input
                                    type="email"
                                    className={`form-control ${touched.userEmail && fieldErrors.userEmail ? 'is-invalid' : ''}`}
                                    placeholder="Enter email"
                                    name="userEmail"
                                    value={form.userEmail}
                                    onChange={handleChange}
                                    onBlur={handleBlur}
                                />
                                {touched.userEmail && fieldErrors.userEmail && (
                                    <div className="invalid-feedback">{fieldErrors.userEmail}</div>
                                )}
                            </div>

                            {/* Password */}
                            <div className="mb-3">
                                <label className="form-label text-muted small mb-1">Password</label>
                                <input
                                    type="password"
                                    className={`form-control ${touched.userPassword && fieldErrors.userPassword ? 'is-invalid' : ''}`}
                                    placeholder="Password"
                                    name="userPassword"
                                    value={form.userPassword}
                                    onChange={handleChange}
                                    onBlur={handleBlur}
                                />
                                {touched.userPassword && fieldErrors.userPassword && (
                                    <div className="invalid-feedback">{fieldErrors.userPassword}</div>
                                )}
                            </div>

                            {/* Role Dropdown */}
                            <div className="mb-4">
                                <label className="form-label text-muted small mb-1">Role:</label>
                                <select
                                    className={`form-select ${touched.role && fieldErrors.role ? 'is-invalid' : ''}`}
                                    name="role"
                                    value={form.role}
                                    onChange={handleChange}
                                    onBlur={handleBlur}
                                >
                                    <option value="">Select your role</option>
                                    <option value="Project Owner">Project Owner</option>
                                    <option value="Assignee">Assignee</option>
                                </select>
                                {touched.role && fieldErrors.role && (
                                    <div className="invalid-feedback">{fieldErrors.role}</div>
                                )}
                            </div>

                            {/* Submit Button - Disabled if form is invalid */}
                            <button
                                type="submit"
                                className="btn btn-brand w-100 py-2 mb-3 shadow-sm"
                                disabled={!isFormValid()}
                            >
                                Login
                            </button>

                            {/* Navigation Link to Signup */}
                            <div className="text-center mt-3">
                                <span className="text-muted small">Don't have an account? </span>
                                <Link to="/signup" className="text-primary text-decoration-none small fw-semibold">
                                    Signup
                                </Link>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default UserLoginForm;
