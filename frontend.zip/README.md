# Issue Tracking System - Frontend (React JS)

A clean, responsive, and robust React frontend built for the **Full_services** microservices project for **Stark Industries / Deloitte USI**.

This project strictly follows the training curriculum, concepts, folder structure, and coding style taught in the training demo (`src.zip`), while faithfully implementing every screen, requirement, validation, and visual layout from the **Deloitte Issue Tracking System UI Reference Specification (v06.2026)**.

---

## 📁 Project Structure

```
issue-tracking-frontend/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx                    # Application entry point with BrowserRouter & AuthProvider
    ├── App.jsx                     # Route declarations & role-based Protected Routes
    ├── App.css                     # Custom styles matching Deloitte & Stark UI specification
    ├── index.css                   # Global styling
    ├── assets/                     # Images, icons, and SVG assets
    │   ├── default-avatar.png
    │   ├── react.svg
    │   └── vite.svg
    ├── context/
    │   └── AuthContext.jsx         # Authentication context (user, isLoggedIn, ctxLogin, ctxLogout)
    ├── model/
    │   ├── User.jsx                # ES6 class model for User
    │   ├── Project.jsx             # ES6 class model for Project
    │   └── Issue.jsx               # ES6 class model for Issue
    ├── services/
    │   ├── mockData.js             # Seed data matching PDF screenshots for offline/interview demos
    │   ├── userService.jsx         # User APIs (login, register, getAllUsers, getUserById)
    │   ├── projectService.jsx      # Project APIs (getAll, getById, getByOwner, create, update, delete)
    │   └── issueService.jsx        # Issue APIs (getAll, getById, getByProject, getByOwner, getByAssignee, create, update)
    └── components/
        ├── UserLoginForm.jsx          # Controlled component login form (Page 4)
        ├── UserSignupForm.jsx         # Uncontrolled component signup form using useRef (Page 4)
        ├── Sidebar.jsx                # Shared responsive dark sidebar with dynamic counters & navigation
        ├── TopBar.jsx                 # Top bar with RegEx search & Deloitte brand header
        ├── IssueCard.jsx              # Kanban card component (Id, Date, Summary, Desc, Assignee, Priority)
        ├── ProjectOwnerDashboard.jsx  # PO Dashboard: Kanban board, filters, RegEx search (Pages 5-6)
        ├── CreateProjectForm.jsx      # Reactive project creation form with date validations (Page 6)
        ├── CreateIssueForm.jsx        # Issue creation form with Prime Story Point validation (Page 7)
        ├── IssueDetails.jsx           # PO Issue Detail screen with 'Edit Issue' button (Page 8)
        ├── EditIssueForm.jsx          # Pre-filled issue editing form with validations (Pages 8-9)
        ├── AssigneeDashboard.jsx      # Assignee Dashboard with assigned issues & search (Page 9)
        └── AssigneeIssueDetails.jsx   # Assignee Details with status dropdown & Save Updates (Page 10)
```

---

## 🚀 How to Run the Application

### Prerequisites
- Node.js (v18+)
- npm or pnpm

### 1. Install Dependencies
```bash
cd issue-tracking-frontend
npm install
```

### 2. Start the Frontend Development Server
```bash
npm run dev
```
The application will be accessible at: `http://localhost:5173/`

### 3. Build for Production
```bash
npm run build
```

---

## 🔌 Connecting with Backend Microservices

The frontend is fully wired to the backend endpoints defined in your `Full_services` project:

| Service | Port | Endpoint Base | API Gateway Route |
|---|---|---|---|
| **APIGateway** | 9000 | `http://localhost:9000` | Routes `/api/users/**`, `/api/projects/**`, `/api/issues/**` |
| **UserServiceMS** | 7002 | `http://localhost:7002/api/users` | `/api/users/login`, `/api/users/register`, `/api/users/all` |
| **ProjectServiceMS** | 7003 | `http://localhost:7003/api/projects` | `/api/projects`, `/api/projects/owner/{ownerId}` |
| **IssueServiceMS** | 7004 | `http://localhost:7004/api/issues` | `/api/issues`, `/api/issues/project/{id}`, `/api/issues/assignee/{id}` |
| **EurekaServer** | 8761 | `http://localhost:8761` | Service Registry |

> **Offline / Interview Demo Support:**
> If the backend microservices or MySQL database are not running during an interview demonstration, the frontend automatically falls back to the persistent demo storage seeded with the exact data from the Deloitte specification PDF (Jack Finn, Antonia Christie, FedEx Courier Service, etc.).

---

## 🎯 Screen Implementation Details & Interview Talking Points

### 1. Login Screen (`UserLoginForm.jsx`)
- **Concept Used:** **Controlled Component** form.
- Form data is driven by React `useState` (`form.userEmail`, `form.userPassword`, `form.role`).
- Validates email format via Regex and password minimum length (6 characters).
- Role dropdown provides **Project Owner** and **Assignee**.
- Submit button is disabled whenever the form is invalid (`!isFormValid()`).
- On successful login, context is updated (`ctxLogin`) and user is automatically routed to their respective dashboard (`/project-dashboard` or `/assignee-dashboard`).

### 2. Signup Screen (`UserSignupForm.jsx`)
- **Concept Used:** **Uncontrolled Component** form.
- Uses React `useRef` hooks (`nameRef`, `emailRef`, `passwordRef`, `profileImageRef`, `roleRef`) to read values directly from the DOM on blur/submit.
- Validates that name is not blank and is at least 2 characters.
- Validates email and password requirements.
- Validates that profile image is a valid URL string starting with `http://` or `https://`.
- Submit button remains disabled if fields are invalid.

### 3. Project Owner Dashboard (`ProjectOwnerDashboard.jsx`)
- **Header:** Features UI Search Bar on the left and `Issue Tracking System` on the right.
- **RegEx Search:** The search bar filters cards across columns dynamically by compiling the input into a `RegExp` matching either the issue `summary` or `description`.
- **Project Selection:** Dropdown populated with projects owned by the logged-in Project Owner. The **first project from the API response is selected by default**.
- **Project Owner Label:** Displays logged-in user name as a label (e.g. `JACK FINN`).
- **Dates Line:** Displays Start Date & End Date formatted as `dd-mm-yyyy`.
- **Frontend Filters:** Includes Filter by Assignee (team members) and Filter by Priority (LOW, MEDIUM, HIGH, ALL).
- **Kanban Board:** 4 columns:
  - 📋 **TO DO** (with count badge)
  - **</> DEVELOPMENT** (with count badge)
  - 🗂️ **TESTING** (with count badge)
  - ✅ **COMPLETED** (with count badge)
- **No Projects Screen:** If the owner has 0 projects, displays `"No Projects Available !"` with a direct link to `"Create Project"`.

### 4. Create Project Screen (`CreateProjectForm.jsx`)
- Fields: `Project Name` (max 150 chars, only allowed special chars: `{ -, /, |, . }`), `Project Owner` (fetched from API), `Project Start Date` & `Project End Date` (Date pickers).
- Validates that `End Date` is not earlier than `Start Date`.
- **CREATE Button:** Enabled only when the form is fully valid, disabled during API submission, redirects to dashboard on success, displays server error on failure.
- **RESET Button:** Clears all fields.

### 5. Create Issue Screen (`CreateIssueForm.jsx`)
- Fields: `Summary` (max 150 chars, no disallowed special chars), `Type` (`BUG`, `TASK`, `STORY`), `Project` (from API), `Description` (optional, max 500 chars), `Priority` (`LOW`, `MEDIUM`, `HIGH`), `Assignee` (from Users API), `Tags` (max 100 chars), `Sprint` (positive integer), `Status` (`TO_DO`, `DEVELOPMENT`, `TESTING`, `COMPLETED`).
- **Prime Number Story Points Validation:** Enforces the strict rule that Story Point **only accepts prime numbers** (e.g. 2, 3, 5, 7, 11, 13, 17, 19, 23...).
- Top banner displays `Deloitte Engineering` matching the PDF screenshot.

### 6. Issue Details Screen (`IssueDetails.jsx`)
- Displays breadcrumb `Project Board / Issue Details`.
- Large golden/orange headline for the issue title.
- Dark `Edit Issue` button that opens the edit screen.
- Clear details section showing Type, Tags (green badge pill), Story Points, Status, Assignee, Sprint, Priority, Created On, and Last Updated.

### 7. Edit Issue Screen (`EditIssueForm.jsx`)
- Pre-populates all existing data of the issue.
- Enforces validations: Summary (5-100), Description (10-500), Sprint & Story Point (positive integers), required dropdowns.
- `EDIT` button enabled only when valid; `RESET` button resets form back to initial loaded state.

### 8. Assignee Dashboard (`AssigneeDashboard.jsx`)
- Dedicated dashboard for team members with role `ASSIGNEE`.
- Sidebar shows profile image, email, and live count of **Issues Assigned**.
- Header contains RegEx search bar.
- Kanban columns show issues assigned to this specific user.
- Clicking any card navigates to **Assignee Issue Details**.

### 9. Assignee Issue Details (`AssigneeIssueDetails.jsx`)
- Breadcrumb `Issue Dashboard / Issue Details`.
- Contains status dropdown menu (`TO-DO`, `DEVELOPMENT`, `TESTING`, `COMPLETED`).
- **Interactive Save Updates:** The `Save Updates` button is **disabled by default** and **only becomes enabled when the status is changed** in the dropdown! Clicking saves the updated status via the API.

---

## 💡 Quick Demo Credentials

For quick evaluation or live demo:
- **Project Owner:**
  - Email: `jack@xyz.com`
  - Password: `password123`
  - Role: `Project Owner`
- **Assignee:**
  - Email: `antonia@xyz.com`
  - Password: `password123`
  - Role: `Assignee`
