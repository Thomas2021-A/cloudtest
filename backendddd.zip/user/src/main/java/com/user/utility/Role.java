package com.user.utility;


public enum Role {
	
	PROJECT_OWNER, ASSIGNEE
}

