package com.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableFeignClients(basePackages = "com.project")
@SpringBootApplication
public class ProjectServiceMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectServiceMsApplication.class, args);
	}

}
