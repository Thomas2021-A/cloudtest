package com.project.utility;

public enum Priority {
	HIGH, MEDIUM, LOW
}
