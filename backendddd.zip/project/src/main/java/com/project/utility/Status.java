package com.project.utility;

public enum Status {
	TO_DO, DEVELOPMENT, TESTING, DONE
}
