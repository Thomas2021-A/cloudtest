package com.project.model;
 
import java.time.LocalDate;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
 
@Data
public class ProjectDTO {
	private Integer id;
 
	@NotBlank(message = "Project name cannot be null")
	@Size(min = 2, max = 255, message = "Project name must be between 2 and 255 characters")
	private String projectName;
	
	@NotNull(message = "Project owner ID cannot be null")
	private Integer projectOwner;
	
	@NotNull(message = "Start date cannot be null")
	private LocalDate startDate;
	
	@FutureOrPresent(message = "End date must be today or in the future")
	private LocalDate endDate;
}