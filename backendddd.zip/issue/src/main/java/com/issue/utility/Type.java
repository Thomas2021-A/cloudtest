package com.issue.utility;

public enum Type {
	BUG, TASK
}
