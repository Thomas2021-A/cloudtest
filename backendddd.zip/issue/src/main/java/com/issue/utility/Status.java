package com.issue.utility;

public enum Status {
	TO_DO, DEVELOPMENT, TESTING, DONE
}
