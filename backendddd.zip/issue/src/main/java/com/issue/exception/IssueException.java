package com.issue.exception;


@SuppressWarnings("serial")
public class IssueException extends Exception{
	public IssueException(String message) {
		super(message);
	}
}
